<template>
   <div class="banner-image-wrap courses-bg-img">
      <div class="banner-content-wrap fill-height bg-warn-overlay">
         <v-row class="align-center justify-center row fill-height">
            <v-col cols="11" sm="11" md="10" lg="10" xl="10">
               <h2 class="white--text">Learn With Your Convenience</h2>
               <h4 class="white--text">Learn any Course anywhere anytime from our 200 courses starting from $60 USD.</h4>
               <v-row class="ma-0">
                  <v-col cols="12" sm="10" md="3" lg="3" xl="3" class="pa-0">
                     <div class="search">
                        <v-form class="search-form">
                           <v-text-field
                              dark
                              color="white"
                              placeholder="Find Your Course"
                           ></v-text-field>
                        </v-form>                             
                     </div>
                  </v-col>
               </v-row>
            </v-col>
         </v-row>
      </div>
   </div>
</template>
