<template>
	<div>
		<page-title-bar></page-title-bar>
	</div>	
</template>

