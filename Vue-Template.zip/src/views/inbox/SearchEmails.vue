<template>
   <div class="search-mail">
      <v-text-field
         label="Search Email"
         placeholder="Search Email"
         solo
         append-icon="search"
      ></v-text-field>
   </div>
</template>

<script>
export default {
  methods: {
  }
};
</script>

