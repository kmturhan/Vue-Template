<template>
   <v-progress-circular indeterminate color="primary"></v-progress-circular>
</template>
