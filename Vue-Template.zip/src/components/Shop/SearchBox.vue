<template>
	<div>
		<ais-search-box 
			placeholder="Search product" 
			class="border input-group" >
		</ais-search-box>
	</div>
</template>   