<template>
   <v-list two-line>
		<v-list-item>
			<v-list-item-content>
			<v-list-item-subtitle>
				<h5 class="fw-bold gray--text">Product Designer</h5>
				<span>AirHelper - London, United Kingdom</span>
			</v-list-item-subtitle>
			</v-list-item-content>
			<v-list-item-action>
			<span class="small">2016 - 2017</span>
			</v-list-item-action>
		</v-list-item>
		<v-list-item>
			<v-list-item-content>
			<v-list-item-subtitle>
				<h5 class="fw-bold gray--text">App Designer</h5>
				<span>AirHelper - London, United Kingdom</span>
			</v-list-item-subtitle>
			</v-list-item-content>
			<v-list-item-action>
			<span class="small">2017 - 2018</span>
			</v-list-item-action>
		</v-list-item>
		<v-list-item>
			<v-list-item-content>
			<v-list-item-subtitle>
				<h5 class="fw-bold gray--text">Service Designer</h5>
				<span>AirHelper - London, United Kingdom</span>
			</v-list-item-subtitle>
			</v-list-item-content>
			<v-list-item-action>
			<span class="small">2015 - 2016</span>
			</v-list-item-action>
		</v-list-item>
	</v-list>
</template>
