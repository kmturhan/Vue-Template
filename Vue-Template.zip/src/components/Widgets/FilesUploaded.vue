<template>
   <div>
      <div class="w-100 px-3">
         <div class="d-inline-flex align-items-center">
            <div class="mr-3">
               <i class="zmdi zmdi-collection-pdf font-lg"></i>
            </div>   
            <div>
               <h5 class="fw-normal mb-0">AX_Report.pdf</h5>
               <small>12/May/2019</small>
            </div>   
         </div> 
      </div>       
      <hr>
       <div class="w-100 px-3">
         <div class="d-inline-flex align-items-center">
            <div class="mr-3">
               <i class="zmdi zmdi-image font-lg"></i>
            </div>
            <div>   
               <h5 class="fw-normal mb-0">Blueprint.jpg</h5>
               <small>08/May/2019</small>
            </div>
         </div>   
      </div>
   </div>
</template>
<script>
export default {
  data() {
    return {
      
    };
  },
  mounted() {
   
  },
  methods: {
   
  }
};
</script>