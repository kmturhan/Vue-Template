<!-- BlogLayoutThree Widget -->
<template>
   <div class="blog-layout-three">
      <v-img
         class="white--text align-end"
         src="/static/img/carousel-slider-2.jpg" height="330px"
      >
			<v-card-title>Top 10 Australian beaches</v-card-title>
      </v-img>
      <v-card-title class="px-6 py-4">
         <div>
				<span class="grey--text fs-12 fw-normal">Number 10</span><br>
				<p class="mb-0">Whitehaven Beach Whitsunday Island,necessitatibus sit exercitationem aut quo quos inventore, Whitsunday Islands, Ullam expedita,necessitatibus sit exercitationem aut quo quos inventore necessitatibus sit exercitationem aut quo quos inventore,
            </p>
         </div>
      </v-card-title>
      <v-card-actions>
         <v-btn icon class="mr-4">
            <v-icon color="success">share</v-icon>
         </v-btn>
         <v-btn icon>
            <v-icon color="error">favorite</v-icon>
         </v-btn>
         <v-spacer></v-spacer>
         <v-btn icon>
            <v-icon class="grey--text">more_horiz</v-icon>
         </v-btn>
      </v-card-actions>
	</div>
</template>