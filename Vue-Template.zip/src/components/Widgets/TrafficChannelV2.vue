<template>
   <v-list class="traffic-channel-widget">
      <v-list-item>
         <p>Direct</p>
         <div>
            <span>55%</span>
            <v-progress-linear value="55" height="7" color="primary"></v-progress-linear>
         </div>
      </v-list-item>
      <v-list-item>
         <p>Referral</p>
         <div>
            <span>78%</span>
            <v-progress-linear value="78" height="7" color="primary"></v-progress-linear>
         </div>
      </v-list-item>
      <v-list-item>
         <p>Facebook</p>
         <div>
            <span>68%</span>
            <v-progress-linear value="68" height="7" color="primary"></v-progress-linear>
         </div>
      </v-list-item>
      <v-list-item>
         <p>Google</p>
         <div>
            <span>23%</span>
            <v-progress-linear value="23" height="7" color="primary"></v-progress-linear>
         </div>
      </v-list-item>
      <v-list-item>
         <p>Instagram</p>
         <div>
            <span>57%</span>
            <v-progress-linear value="57" height="7" color="primary"></v-progress-linear>
         </div>
      </v-list-item>
   </v-list>
</template>
