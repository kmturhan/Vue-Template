<template>
   <div class="profile-head app-card mb-30">
      <div class="profile-top">
        <img src="/static/img/profile-banner.jpg" alt="profile banner" width="1920" height="165" />
      </div>
      <div class="profile-bottom border-bottom-light-1">
        <div class="user-image text-center mb-4">
          <img src="/static/avatars/user-7.jpg" class="img-responsive rounded-circle" alt="user images" />
        </div>
        <div class="user-list-content">
          <div class="text-center">
            <h3 class="fw-bold">Gregory A.</h3>
            <p>Web Designer & Developer</p>
            <div class="social-list clearfix mb-5">
              <ul class="list-inline d-inline-block">
                <li><a href="javascript:void(0);" class="pink--text"><i class="ti-facebook"></i></a></li>
                <li><a href="javascript:void(0);" class="pink--text"><i class="ti-twitter-alt"></i></a></li>
                <li><a href="javascript:void(0);" class="pink--text"><i class="ti-google"></i></a></li>
                <li><a href="javascript:void(0);" class="pink--text"><i class="ti-linkedin"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="user-activity text-center">
        <ul class="list-inline d-inline-block">
          <li>
            <span class="fw-bold">588</span>
            <span>Articles</span>
          </li>
          <li>
            <span class="fw-bold">2400</span>
            <span>Followers</span>
          </li>
          <li>
            <span class="fw-bold">1200</span>
            <span>Following</span>
          </li>
        </ul>
      </div>
    </div>
</template>
