export default {
   primary: '#82B1FF',
   secondary: '#424242',
   accent: '#5D92F4',
   error: '#FF3739',
   info: '#00D0BD',
   success: '#00D014',
   warning: '#FFB70F'
}